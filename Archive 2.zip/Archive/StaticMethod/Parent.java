package com.company.StaticMethod;

public class Parent {

    public static void staticMethod(){
        System.out.println("parent static method");
    }
}
