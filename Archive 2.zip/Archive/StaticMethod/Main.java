package com.company.StaticMethod;

public class Main {
    public static void main(String[] args) {
        Child1.staticMethod();
    }
}
