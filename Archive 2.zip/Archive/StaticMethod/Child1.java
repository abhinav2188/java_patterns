package com.company.StaticMethod;

public class Child1 extends Parent{

    public static void staticMethod(){
        System.out.println("child1 static method");
    }

}
