package com.company.designPatterns.Singleton;

public enum EnumSingleton {

    INSTANCE(12);

    EnumSingleton(int i) {
    }

    private int property;


}
