package com.company.designPatterns.Singleton;

public class Main {

    // requirements
    // 1. object is created only once and shared among all the threads
    // 2. classes are not allowed to create object of this class only they can access instance of the singleton

    public static void main(String[] args) {

    }

}
