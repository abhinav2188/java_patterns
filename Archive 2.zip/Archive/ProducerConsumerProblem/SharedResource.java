package com.company.ProducerConsumerProblem;

import java.sql.SQLOutput;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Random;

public class SharedResource {

    private int size;
    private Queue<Integer> buffer;


    public SharedResource(int size){
        this.size = size;
        this.buffer = new ArrayDeque<>();
    }

    public synchronized void produceItem(){
        while(buffer.size() == size) {
            System.out.println("waiting for the buffer to get empty");
            try {
                wait();
            } catch (Exception e) {
                // handle exception
            }
        }
        int item = new Random().nextInt();
        System.out.println("item produced: "+item);
        buffer.add(item);
        notifyAll();

    }

    public synchronized void consumeItem(){
        while (buffer.isEmpty()){
            try{
                System.out.println("waiting for the buffer to be filled");
                wait();
            }catch (InterruptedException e) {
                e.printStackTrace();
                // handle exception
            }
        }
        System.out.println("item consumed: "+ buffer.poll());
        notifyAll();
    }


}
