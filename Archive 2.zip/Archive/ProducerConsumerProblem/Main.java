package com.company.ProducerConsumerProblem;

public class Main {

    public static void main(String[] args) {

        SharedResource sharedResource = new SharedResource(3);

        Thread producerThread = new Thread(()->{
            try {
                for(int i=0; i<10; i++) {
                    Thread.sleep(1000);
                    sharedResource.produceItem();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        producerThread.start();

        Thread consumerThread = new Thread(()->{
            try {
                for(int i=0;i<8;i++) {
                    Thread.sleep(3000);
                    sharedResource.consumeItem();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        consumerThread.start();

    }

}
